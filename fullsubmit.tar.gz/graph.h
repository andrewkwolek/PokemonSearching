// Project Identifier: 5949F553E20B650AB0FB2266D3C0822B13D248B0

#include <vector>
#include <iostream>

struct coord {
	int x;
	int y;
};

struct edge {
	int start;
	int end;
	float weight;
};

class Graph {
private:


};